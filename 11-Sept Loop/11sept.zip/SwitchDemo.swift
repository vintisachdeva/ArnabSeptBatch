//: Playground - noun: a place where people can play

import UIKit

var str = "a"

//  no need to explicitly specify break. automatically break or exit from switch when particular condition satisfied.
// no work without body

//vowel or consonant

switch str {
case "A", "a", "E", "e", "I", "i", "O", "o", "U", "u":
    print("vowel")

/*case "E", "e":
        print("vowel")
    
case "I":
    print("Vowel")

case "O":
    print("vowel")

case "U":
    print("vowel")
*/
default:
    print("consonant")
}