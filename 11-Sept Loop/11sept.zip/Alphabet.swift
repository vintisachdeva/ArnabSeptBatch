//: Playground - noun: a place where people can play

import UIKit

var num : Int = 1


var firstName = "RAM ROHAN "
var lastName = "sagar kumar"

//print("Hello " + firstName + lastName)

firstName.lowercased()

lastName.uppercased()

lastName.capitalized

var num2 = 5

var active = false



if active{
    print("is true")
}
    else
{
print("is false")
}

num2 + num

//print(firstName+ " " + lastName)


print(type(of: num))

typealias value1 = UInt8// unsignedInt will always take from 0 to max range
                        //signed and Int take negative to positive

var value = value1.min

var age = 21

//string interpolation

print("You can vote if your \(age) is greater than \(age)")

print("You are printing some data again", terminator:"")
print("printing again")




















