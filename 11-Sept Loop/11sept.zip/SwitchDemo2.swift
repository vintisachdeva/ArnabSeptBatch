//: Playground - noun: a place where people can play

import UIKit

var str = 5

switch str {
case 0:
    print("its 0")
case 5..<1:
    print("its between 1 to 5")
case 10..<5:
    print("its between 5 to 10")
default:
    print("its out of limit")
}